/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Gaming Pc
 *
 * Created on June 26, 2022, 2:03 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

  float costOfGas;
const float EXCISE_TAX_GAS = 0.39;
const float SALES_TAX = 0.08;
const float CAP_AND_TRADE_FEE = 0.10;
const float FED_EXCISE_TAX = .184;
float gasAfterTaxes;

cout << "How much did you pay per gallon of gas? \n";
cin >> costOfGas;

gasAfterTaxes = (costOfGas * SALES_TAX) + EXCISE_TAX_GAS + CAP_AND_TRADE_FEE + FED_EXCISE_TAX;

float amountNoFees; 

amountNoFees = costOfGas - gasAfterTaxes; 

float taxPercentage;
taxPercentage = (gasAfterTaxes/costOfGas)*100;
        
float companyProfit;

companyProfit = amountNoFees * 0.065;

cout << fixed << setprecision(2) << "Percent of Gas Tax per gallon of gas = %" << taxPercentage <<endl;
cout << "The company made a total of = $" << companyProfit<< " per gallon of gas."<< endl;
cout << "The government took = $" << gasAfterTaxes << " in taxes"; 



return 0;
    
}

