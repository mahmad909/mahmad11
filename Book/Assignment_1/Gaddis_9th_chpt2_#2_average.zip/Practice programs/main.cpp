/* 
 * File:   main.cpp
 * Author: Mujahid Ahmad
 * Created on June 21, 2022, 3:47 Pm
 * Purpose:Sum of two numbers  
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
    int n1 = 28, n2 = 32, n3 = 37, n4 = 24, n5 = 33, sum, average;
    sum = n1 + n2 + n3 + n4 + n5;
    cout << "The sum of 28, 32, 37, 24, & 33 is: ";
    cout << sum << endl;
    cout << "The average of the numbers are: ";
    average = sum / 5;
    cout << average;
            
            
            
    
            
    return 0;
}