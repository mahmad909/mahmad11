/* 
 * File:   main.cpp
 * Author: Mujahid Ahmad
 * Created on June 21, 2022, 3:56 Pm
 * Purpose:annual pay
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
    float payAmout = 2200.0, payPeroids = 26, annualPay;
    annualPay = payAmout * payPeroids; 
    cout << "The annual pay for the job will be: ";
    cout << annualPay; 
    
            
    return 0;
}