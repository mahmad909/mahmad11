/* 
 * File:   main.cpp
 * Author: Mujahid Ahmad
 * Created on June 21, 2022, 8:32 Pm
 * Purpose:Give two results to user   
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
    char le;
    
    cout << "Input a character to turn it into a big C\n";
    cin >> le;
    cout << "Now watch the magic happen\n";
    cout << "  " <<  le << " " << le << " " << le << "\n";
    cout <<" " << le <<"     " << le << endl;
    cout << le << endl;
    cout << le << endl;
    cout << le << endl;
    cout << le << endl;
    cout << " " << le << "     " << le << endl;
    cout << "  " <<  le << " " << le << " " << le << endl;
   
    return 0;
}