/* 
 * File:   main.cpp
 * Author: Mujahid Ahmad
 * Created on June 24, 2022, 1:15 m
 * Purpose:adding Customer items and taxes
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
   
    // p stands for price of product
    // Number after p stands for which product it is
    // Sbtot = subtotal, Stax = state tax, total = sub total + state tax
    
    //Listing off each item with their price
    cout << "    *\n";
    cout << "   ***\n";
    cout << "  *****\n";
    cout << " *******\n";
    cout << "  *****\n";
    cout << "   ***\n";
    cout << "    *\n";
   
    return 0;
}